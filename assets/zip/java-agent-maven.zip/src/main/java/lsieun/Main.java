package lsieun;

public class Main {
    public static void main(String[] args) {
        System.out.println("This is a Java Agent Jar");
    }
}
